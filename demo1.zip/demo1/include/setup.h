#ifndef setup_h
#define setup_h

#include <stm32f4xx_hal.h>

void vThreadSetup(void *pvParameters);
void vThreadDataAquisition(void *pvParameters);

#endif
